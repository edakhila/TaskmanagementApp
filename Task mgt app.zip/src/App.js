import logo from './logo.svg';
import './App.css';
import "bootstrap/dist/css/bootstrap.min.css"
import TaskManagmentDash from "./TaskManagmentDash"

function App() {
  return (
    <div className="App">
      < TaskManagmentDash />
    </div>
  );
}

export default App;
